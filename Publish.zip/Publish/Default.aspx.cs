﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class _Default : Page
{
    string dbConnectionString = ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString;
    int id;
    string name = "";
    string description = "";
    int price;
    protected void Page_Load(object sender, EventArgs e)
    {
        if(Page.IsPostBack == false)
        {
            ShowSearchGrid(0, id, name, description, price, dbConnectionString);
        }
    }
 
    private void ShowSearchGrid(int pageNum, int id, string name, string description, int price, string dbConnectionString)
    {
        try
        {
            using (SqlConnection con = new SqlConnection(dbConnectionString))
            {
                SqlDataAdapter da = new SqlDataAdapter();
                DataSet ds = new DataSet();
                SqlCommand cmd = new SqlCommand("usp_GetProducts", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ProductID", id);
                cmd.Parameters.AddWithValue("@ProductName", name);
                cmd.Parameters.AddWithValue("@ProductDescription", description);
                cmd.Parameters.AddWithValue("@ProductPrice", price);
                con.Open();
                cmd.CommandTimeout = 0;
                da.SelectCommand = cmd;
                da.Fill(ds, "Product");
                GridView1.PageIndex = pageNum;
                GridView1.DataSource = ds.Tables["Product"];
                GridView1.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw new Exception(String.Format("Error While Getting Product Details - Error: {0}", ex.Message));
        }
    }

    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        ShowSearchGrid(e.NewPageIndex, id, name, description, price, dbConnectionString);
    }

    protected void Button1_Click(object sender, EventArgs e)  //Search Operation
    {
        if (TextBox1.Text == "")
        {
            Label1.Visible = true;
            Label1.Text = "Prod ID Textbox Cannot Be Empty";
        }
        else
        {
            Label1.Visible = false;
            id = Convert.ToInt32(TextBox1.Text);
            ShowSearchGrid(0, id, name, description, price, dbConnectionString);
        }
    }
    
    protected void Button2_Click(object sender, EventArgs e)  //Insert Operation
    {
        if (TextBox2.Text == "" || TextBox3.Text == "" || TextBox4.Text == "" || TextBox5.Text == "")
        {
            Label1.Visible = true;
            Label1.Text = "While Inserting, No Textbox Should Be Empty";
        }
        else
        {
            Label1.Visible = false;
            id = Convert.ToInt32(TextBox2.Text);
            name = TextBox3.Text;
            description = TextBox4.Text;
            price = Convert.ToInt32(TextBox5.Text);
            InsertProduct(id, name, description, price, dbConnectionString);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Product Inserted Successfully')", true);
            Page_Load(sender, e);
            TextBox2.Text = TextBox3.Text = TextBox4.Text = TextBox5.Text = "";
        }
    }

    private void InsertProduct(int  id, string name, string description, int price, string dbConnectionString)
    {
        try
        {
            using (SqlConnection con = new SqlConnection(dbConnectionString))
            {
                SqlCommand cmd = new SqlCommand("usp_InsertProduct", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ProductID", id);
                cmd.Parameters.AddWithValue("@ProductName", name);
                cmd.Parameters.AddWithValue("@ProductDescription", description);
                cmd.Parameters.AddWithValue("@ProductPrice", price);
                con.Open();
                cmd.CommandTimeout = 0;
                cmd.ExecuteNonQuery();
            }
        }
        catch (Exception ex)
        {
            throw new Exception(String.Format("Error While Inserting New Product - Error: {0}", ex.Message));
        }
    }

    protected void Button3_Click(object sender, EventArgs e)    //Update Operation
    {
        if (TextBox2.Text == "" || TextBox3.Text == "" || TextBox4.Text == "" || TextBox5.Text == "")
        {
            Label1.Visible = true;
            Label1.Text = "While Updating, No Textbox Should Be Empty";
        }
        else
        {
            Label1.Visible = false;
            id = Convert.ToInt32(TextBox2.Text);
            name = TextBox3.Text;
            description = TextBox4.Text;
            price = Convert.ToInt32(TextBox5.Text);
            UpdateProduct(id, name, description, price, dbConnectionString);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Product Information Updated')", true);
            Page_Load(sender, e);
            TextBox2.Text = TextBox3.Text = TextBox4.Text = TextBox5.Text = "";
        }
    }

    private void UpdateProduct(int id, string name, string description, int price, string dbConnectionString)
    {
        try
        {
            using (SqlConnection con = new SqlConnection(dbConnectionString))
            {
                SqlCommand cmd = new SqlCommand("usp_UpdateProduct", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ProductID", id);
                cmd.Parameters.AddWithValue("@ProductName", name);
                cmd.Parameters.AddWithValue("@ProductDescription", description);
                cmd.Parameters.AddWithValue("@ProductPrice", price);
                con.Open();
                cmd.CommandTimeout = 0;
                cmd.ExecuteNonQuery();
            }
        }
        catch (Exception ex)
        {
            throw new Exception(String.Format("Error While Updating Product Detail - Error: {0}", ex.Message));
        }
    }

    protected void Button4_Click(object sender, EventArgs e)   //Delete Operation
    {
        id = Convert.ToInt32(TextBox2.Text);
        DeleteProduct(id, dbConnectionString);
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Product Information Deleted')", true);
        Page_Load(sender, e);
        TextBox2.Text = TextBox3.Text = TextBox4.Text = TextBox5.Text = "";
    }

    private void DeleteProduct(int id, string dbConnectionString)
    {
        try
        {
            using (SqlConnection con = new SqlConnection(dbConnectionString))
            {
                SqlCommand cmd = new SqlCommand("usp_DeleteProduct", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ProductID", id);
                con.Open();
                cmd.CommandTimeout = 0;
                cmd.ExecuteNonQuery();
            }
        }
        catch (Exception ex)
        {
            throw new Exception(String.Format("Error While Deleting Product Detail - Error: {0}", ex.Message));
        }
    }
}