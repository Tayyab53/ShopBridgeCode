USE [ShopBridge]

/****** Object:  StoredProcedure [dbo].[usp_DeleteProduct]    Script Date: 8/16/2021 1:18:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* ==============================================================================*/
/* OBJECT NAME:     usp_DeleteProduct */
/* AUTHOR:          Syed Bukhari */
/* CREATED ON :     14 Aug 2021  */
/* VERSION #:       1.01   */
/* PURPOSE:         Delete Product  */
/* EXECUTED FROM:   Web Application   */
/* ==============================================================================*/

-----------------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[usp_DeleteProduct]
----------------------------------------------------------------------------------------------------------------------------------- 
(
@ProductID INT
)
AS
BEGIN 
DECLARE @ErrState INT,
	@ErrSeverity INT,
	@ErrMsg VARCHAR(200)
		
BEGIN TRY
DELETE FROM Products WHERE ProductID = @ProductID
END TRY

BEGIN CATCH
SET @ErrMsg = ERROR_PROCEDURE() + ': ' + ERROR_MESSAGE()
SET @ErrState = ERROR_STATE()
SET @ErrSeverity = ERROR_SEVERITY()
RAISERROR(@ErrMsg, @ErrSeverity, @ErrState)
END CATCH

END
GO

