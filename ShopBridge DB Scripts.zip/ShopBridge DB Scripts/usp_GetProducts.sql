USE [ShopBridge]

/****** Object:  StoredProcedure [dbo].[usp_GetProducts]    Script Date: 8/16/2021 1:18:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* ==============================================================================*/
/* OBJECT NAME:     usp_GetProducts */
/* AUTHOR:          Syed Bukhari */
/* CREATED ON :     14 Aug 2021  */
/* VERSION #:       1.01   */
/* PURPOSE:         Get Products  */
/* EXECUTED FROM:   Web Application   */
/* ==============================================================================*/

-----------------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[usp_GetProducts]
----------------------------------------------------------------------------------------------------------------------------------- 
(
@ProductID INT,
@ProductName VARCHAR(MAX),
@ProductDescription VARCHAR(MAX),
@ProductPrice INT
)
AS
BEGIN 
DECLARE @ErrState INT,
	@ErrSeverity INT,
	@ErrMsg VARCHAR(200)
		
BEGIN TRY

IF (@ProductID > 0)
BEGIN
SELECT * FROM Products (Nolock) WHERE ProductID = @ProductID 
END

ELSE
BEGIN
SELECT * FROM Products (Nolock) 
END
END TRY

BEGIN CATCH
SET @ErrMsg = ERROR_PROCEDURE() + ': ' + ERROR_MESSAGE()
SET @ErrState = ERROR_STATE()
SET @ErrSeverity = ERROR_SEVERITY()
RAISERROR(@ErrMsg, @ErrSeverity, @ErrState)
END CATCH

END
GO