CREATE DATABASE ShopBridge;

USE [ShopBridge]
GO
/****** Object:  Table [dbo].[Products]    Script Date: 8/16/2021 1:18:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Products](
	[S.No] [numeric](18, 0) IDENTITY(1,1) NOT NULL,
	[ProductID] [numeric](18, 0) NOT NULL,
	[ProductName] [nvarchar](50) NOT NULL,
	[ProductDescription] [nvarchar](50) NOT NULL,
	[ProductPrice] [numeric](18, 0) NOT NULL,
 CONSTRAINT [PK_Products] PRIMARY KEY CLUSTERED 
(
	[ProductID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET IDENTITY_INSERT [dbo].[Products] ON 

INSERT [dbo].[Products] ([S.No], [ProductID], [ProductName], [ProductDescription], [ProductPrice]) VALUES (CAST(1 AS Numeric(18, 0)), CAST(1001 AS Numeric(18, 0)), N'SONY TV', N'Android TV', CAST(74000 AS Numeric(18, 0)))
INSERT [dbo].[Products] ([S.No], [ProductID], [ProductName], [ProductDescription], [ProductPrice]) VALUES (CAST(2 AS Numeric(18, 0)), CAST(1002 AS Numeric(18, 0)), N'LG Mobile', N'Latest Android Smartphone', CAST(9000 AS Numeric(18, 0)))
INSERT [dbo].[Products] ([S.No], [ProductID], [ProductName], [ProductDescription], [ProductPrice]) VALUES (CAST(3 AS Numeric(18, 0)), CAST(1003 AS Numeric(18, 0)), N'Sony Mobile', N'Latest Android Smartphone', CAST(20000 AS Numeric(18, 0)))
INSERT [dbo].[Products] ([S.No], [ProductID], [ProductName], [ProductDescription], [ProductPrice]) VALUES (CAST(4 AS Numeric(18, 0)), CAST(1004 AS Numeric(18, 0)), N'Samsung TV', N'Android Television', CAST(75000 AS Numeric(18, 0)))
INSERT [dbo].[Products] ([S.No], [ProductID], [ProductName], [ProductDescription], [ProductPrice]) VALUES (CAST(5 AS Numeric(18, 0)), CAST(1005 AS Numeric(18, 0)), N'MI Mobile', N'Latest Android Smartphone', CAST(10000 AS Numeric(18, 0)))
INSERT [dbo].[Products] ([S.No], [ProductID], [ProductName], [ProductDescription], [ProductPrice]) VALUES (CAST(6 AS Numeric(18, 0)), CAST(1009 AS Numeric(18, 0)), N'SONY Mobile', N'Android Mobile', CAST(38000 AS Numeric(18, 0)))
INSERT [dbo].[Products] ([S.No], [ProductID], [ProductName], [ProductDescription], [ProductPrice]) VALUES (CAST(7 AS Numeric(18, 0)), CAST(1010 AS Numeric(18, 0)), N'LG TV', N'Android TV', CAST(56000 AS Numeric(18, 0)))
INSERT [dbo].[Products] ([S.No], [ProductID], [ProductName], [ProductDescription], [ProductPrice]) VALUES (CAST(8 AS Numeric(18, 0)), CAST(1012 AS Numeric(18, 0)), N'Whirlpool', N'Fridge', CAST(14000 AS Numeric(18, 0)))
INSERT [dbo].[Products] ([S.No], [ProductID], [ProductName], [ProductDescription], [ProductPrice]) VALUES (CAST(9 AS Numeric(18, 0)), CAST(1013 AS Numeric(18, 0)), N'Onida', N'LCD', CAST(10000 AS Numeric(18, 0)))
INSERT [dbo].[Products] ([S.No], [ProductID], [ProductName], [ProductDescription], [ProductPrice]) VALUES (CAST(10 AS Numeric(18, 0)), CAST(1018 AS Numeric(18, 0)), N'Lenovo TV', N'LED', CAST(34500 AS Numeric(18, 0)))
INSERT [dbo].[Products] ([S.No], [ProductID], [ProductName], [ProductDescription], [ProductPrice]) VALUES (CAST(11 AS Numeric(18, 0)), CAST(1019 AS Numeric(18, 0)), N'Samsung Mobile', N'Android Mobile', CAST(56300 AS Numeric(18, 0)))
INSERT [dbo].[Products] ([S.No], [ProductID], [ProductName], [ProductDescription], [ProductPrice]) VALUES (CAST(12 AS Numeric(18, 0)), CAST(1020 AS Numeric(18, 0)), N'Realme Mobile', N'Handset', CAST(18000 AS Numeric(18, 0)))
INSERT [dbo].[Products] ([S.No], [ProductID], [ProductName], [ProductDescription], [ProductPrice]) VALUES (CAST(13 AS Numeric(18, 0)), CAST(1021 AS Numeric(18, 0)), N'Lenovo Mobile', N'Android Handset', CAST(12000 AS Numeric(18, 0)))
SET IDENTITY_INSERT [dbo].[Products] OFF