USE [ShopBridge]

/****** Object:  StoredProcedure [dbo].[usp_UpdateProduct]    Script Date: 8/16/2021 1:18:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* ==============================================================================*/
/* OBJECT NAME:     usp_UpdateProduct */
/* AUTHOR:          Syed Bukhari */
/* CREATED ON :     14 Aug 2021  */
/* VERSION #:       1.01   */
/* PURPOSE:         Update Product  */
/* EXECUTED FROM:   Web Application   */
/* ==============================================================================*/

-----------------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[usp_UpdateProduct]
----------------------------------------------------------------------------------------------------------------------------------- 
(
@ProductID INT,
@ProductName VARCHAR(MAX),
@ProductDescription VARCHAR(MAX),
@ProductPrice INT
)
AS
BEGIN 
DECLARE @ErrState INT,
	@ErrSeverity INT,
	@ErrMsg VARCHAR(200)
		
BEGIN TRY
UPDATE Products SET ProductName = @ProductName, ProductDescription = @ProductDescription, ProductPrice = @ProductPrice WHERE ProductID = @ProductID
END TRY

BEGIN CATCH
SET @ErrMsg = ERROR_PROCEDURE() + ': ' + ERROR_MESSAGE()
SET @ErrState = ERROR_STATE()
SET @ErrSeverity = ERROR_SEVERITY()
RAISERROR(@ErrMsg, @ErrSeverity, @ErrState)
END CATCH

END
GO